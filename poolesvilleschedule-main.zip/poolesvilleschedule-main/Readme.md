If you're into programming, I've kept the github repo public for y'all to see.

Note: You might have realized that I put the CSS and JS code all into one html file (which isn't a very good thing to do). I understand, it's just that I needed to make this as easy as possible to upload to the Poolesville website - *if* I do.

Disregard previous note now ig
